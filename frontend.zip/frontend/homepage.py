from fasthtml.common import *

# Create a FastHTML application
app, rt = fast_app()

# Define the route for the homepage
@rt("/")
def home():
    # Read the contents of index.html
    with open("index.html", "r") as file:
        html_content = file.read()
    return html_content

# Start the server
serve()
