# Falcon_29-12-24
Learn how to build an animated, fully responsive restaurant website using HTML, CSS, and JavaScript!
